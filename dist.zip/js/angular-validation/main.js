var angular = require('./node_modules/angular/angular.js');
var validationApp = require('./src/module.js');
